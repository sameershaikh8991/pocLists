package com.user.external;


public class HotelService {
}
